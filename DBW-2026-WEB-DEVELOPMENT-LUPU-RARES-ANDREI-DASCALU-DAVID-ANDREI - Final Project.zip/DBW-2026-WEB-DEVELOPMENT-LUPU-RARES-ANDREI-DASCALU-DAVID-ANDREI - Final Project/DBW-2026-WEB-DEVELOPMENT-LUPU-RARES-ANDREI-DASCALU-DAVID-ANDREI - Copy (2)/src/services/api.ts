const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

async function request(path: string, options: RequestInit = {}) {
  const token = localStorage.getItem("token");

  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
    ...options,
  });

  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }

  return response.json();
}

export const authAPI = {
  login: (email: string, password: string) =>
    request("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),

   register: (username: string, email: string, password: string) =>
    request("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ username, email, password }),
    }),

  signup: (username: string, email: string, password: string) =>
    request("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ username, email, password }),
    }),

  getProfile: () => request("/api/auth/profile"),
};

export const lobbyAPI = {
  getPublicLobbies: () => request("/api/lobby/public"),

  createLobby: (data: any) =>
    request("/api/lobby/create", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  joinLobby: (roomCode: string) =>
    request("/api/lobby/join", {
      method: "POST",
      body: JSON.stringify({ roomCode }),
    }),

  leaveLobby: (roomCode: string) =>
    request("/api/lobby/leave", {
      method: "POST",
      body: JSON.stringify({ roomCode }),
    }),

  getLobby: (roomCode: string) => request(`/api/lobby/${roomCode}`),
};

export const gameAPI = {
  getStats: () => request("/api/game/stats"),

  saveScore: (data: any) =>
    request("/api/game/score", {
      method: "POST",
      body: JSON.stringify(data),
    }),
};