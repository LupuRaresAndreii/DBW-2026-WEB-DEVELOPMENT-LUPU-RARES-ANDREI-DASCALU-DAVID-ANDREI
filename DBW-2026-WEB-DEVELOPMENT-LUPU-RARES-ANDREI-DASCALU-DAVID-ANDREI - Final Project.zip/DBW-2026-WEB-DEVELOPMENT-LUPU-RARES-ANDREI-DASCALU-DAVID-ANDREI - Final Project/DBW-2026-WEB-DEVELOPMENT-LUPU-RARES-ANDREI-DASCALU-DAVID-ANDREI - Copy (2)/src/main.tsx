import React from "react";
import ReactDOM from "react-dom/client";
import App from "./app/App";
import { SocketProvider } from "./context/SocketContext";
import "./styles/index.css";


ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <SocketProvider>
      <App />
    </SocketProvider>
  </React.StrictMode>
);