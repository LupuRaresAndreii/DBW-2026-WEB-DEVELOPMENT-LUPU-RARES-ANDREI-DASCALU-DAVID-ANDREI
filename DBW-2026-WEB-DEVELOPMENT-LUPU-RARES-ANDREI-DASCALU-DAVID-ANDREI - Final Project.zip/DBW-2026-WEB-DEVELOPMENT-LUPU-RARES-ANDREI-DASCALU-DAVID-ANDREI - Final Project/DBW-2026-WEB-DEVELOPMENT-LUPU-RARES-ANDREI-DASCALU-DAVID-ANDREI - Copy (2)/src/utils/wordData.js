export const WORD_POOL = [
  {
    masterWord: "THEREIN",
    subWords: ["THE", "HE", "HER", "HERE", "ERE", "THERE", "REIN", "IN"]
  },
  {
    masterWord: "HEARTH",
    subWords: ["HE", "HEAR", "HEART", "EAR", "EARTH", "ART"]
  },
  {
    masterWord: "FEATHER",
    subWords: ["FEAT", "EAT", "AT", "THE", "HE", "HER"]
  },
  {
    masterWord: "SPARKLE",
    subWords: ["SPA", "SPAR", "SPARK", "PARK", "ARK"]
  },
  {
    masterWord: "STABLE",
    subWords: ["STAB", "TAB", "TABLE", "ABLE"]
  },
  {
    masterWord: "BEARING",
    subWords: ["BE", "BEAR", "EAR", "RING", "IN"]
  },
  {
    masterWord: "PANTHEON",
    subWords: ["PAN", "PANT", "AN", "ANT", "THE", "HE", "ON"]
  },
  {
    masterWord: "CARPENTER",
    subWords: ["CAR", "CARP", "PEN", "PENT", "ENTER", "TEN"]
  },
  {
    masterWord: "STRANGER",
    subWords: ["RAN", "RANG", "RANGE", "RANGER", "AN", "ANGER"]
  },
  {
    masterWord: "FORGET",
    subWords: ["FOR", "OR", "FORGE", "GET"]
  },
  {
    masterWord: "SOMETHING",
    subWords: ["SO", "SOME", "MET", "ME", "THIN", "THING", "IN"]
  },
  {
    masterWord: "BANDAGE",
    subWords: ["BAN", "BAND", "AND", "AGE"]
  },
  {
    masterWord: "SEASONING",
    subWords: ["SEA", "SEASON", "SON", "ON", "IN"]
  },
  {
    masterWord: "THREATEN",
    subWords: ["THREAT", "EAT", "AT", "TEN"]
  },
  {
    masterWord: "WASHING",
    subWords: ["WASH", "ASH", "SHIN", "IN"]
  },
  {
    masterWord: "PRICELESS",
    subWords: ["PRICE", "RICE", "ICE", "LESS"]
  },
  {
    masterWord: "CATCHER",
    subWords: ["CAT", "CATCH", "AT", "HE", "HER"]
  },
  {
    masterWord: "STARTLE",
    subWords: ["STAR", "TAR", "TART", "ART"]
  },
  {
    masterWord: "FRIENDSHIP",
    subWords: ["FRIEND", "END", "HIP"]
  },
  {
    masterWord: "HOSTAGE",
    subWords: ["HOST", "STAG", "STAGE", "TAG", "AGE"]
  }
];

export const getRandomWords = (count = 5) => {
  const shuffled = [...WORD_POOL].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};

export const validateWord = (masterWord, subWord) => {
  const wordData = WORD_POOL.find(w => w.masterWord === masterWord.toUpperCase());
  if (!wordData) return false;

  return wordData.subWords.includes(subWord.toUpperCase());
};