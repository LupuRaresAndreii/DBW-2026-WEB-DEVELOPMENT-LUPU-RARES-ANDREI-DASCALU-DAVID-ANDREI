import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { SmilePlus, Frown } from "lucide-react";
import { validateWord as validateWordFromPool } from "../../utils/wordData";
import { useSocket } from "../../context/SocketContext";

const getStoredMultiplayerWords = () => {
  const stored = localStorage.getItem("multiplayerWords");

  if (stored) {
    return JSON.parse(stored);
  }

  return ["THEREIN", "HEARTH", "FEATHER", "SPARKLE", "STABLE"];
};
const ROUND_DURATION = 60;
const TOTAL_ROUNDS = 5;

interface PlayerScore {
  name: string;
  score: number;
  correctWords: number;
  wrongWords: number;
}

export function MultiplayerGame() {
  const navigate = useNavigate();
  const { socket, isConnected } = useSocket();
const roomCode = localStorage.getItem("roomCode") || "";
  const [username, setUsername] = useState("");
  const [word, setWord] = useState("");
  const [faceState, setFaceState] = useState<"neutral" | "happy" | "sad">("neutral");
  const [timeLeft, setTimeLeft] = useState(ROUND_DURATION);
  const [currentRound, setCurrentRound] = useState(0);
const [masterWords, setMasterWords] = useState<string[]>(
  getStoredMultiplayerWords()
);
const [masterWord, setMasterWord] = useState(getStoredMultiplayerWords()[0]);  const [correctWords, setCorrectWords] = useState<string[]>([]);
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [totalSubmissions, setTotalSubmissions] = useState(0);

  // Mock player scores - in real implementation this would be synced with backend
  const [playerScores, setPlayerScores] = useState<PlayerScore[]>([]);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");

    if (!isLoggedIn) {
      navigate("/");
    } else {
     const name = storedUsername || "User";
setUsername(name);

setPlayerScores([
  {
    name,
    score: 0,
    correctWords: 0,
    wrongWords: 0,
  },
]);

    }
  }, [navigate]);

  useEffect(() => {
  if (!socket || !isConnected || !roomCode || !username) return;

  socket.emit("join-game", {
    roomCode,
    username,
  });

  socket.on("scoreboard-updated", (scores) => {
    setPlayerScores(scores);
  });

  socket.on("game-words", ({ words }) => {
    if (words && words.length > 0) {
      setMasterWords(words);
      setMasterWord(words[currentRound] || words[0]);
      localStorage.setItem("multiplayerWords", JSON.stringify(words));
    }
  });

  socket.on("final-scoreboard", (scores) => {
    const myStats =
      scores.find((player: PlayerScore) => player.name === username) || {
        name: username,
        score: 0,
        correctWords: 0,
        wrongWords: 0,
      };

    navigate("/multiplayer-game-over", {
      state: {
        playerScores: scores,
        myScore: myStats.score,
        correctWords: myStats.correctWords,
        wrongWords: myStats.wrongWords,
      },
    });
  });

  return () => {
    socket.off("scoreboard-updated");
    socket.off("game-words");
    socket.off("final-scoreboard");
  };
}, [socket, isConnected, roomCode, username, currentRound, navigate]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Round ended
          if (currentRound + 1 >= TOTAL_ROUNDS) {
            // Game over
            if (socket && isConnected && roomCode) {
  socket.emit("game-finished", { roomCode });
}
return 0;
          } else {
            // Next round
            setCurrentRound((prev) => prev + 1);
setMasterWord(masterWords[(currentRound + 1) % masterWords.length]);
            return ROUND_DURATION;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
}, [currentRound, masterWords, socket, isConnected, roomCode]);
  const validateWord = (word: string): boolean => {
  const wordUpper = word.toUpperCase();

  if (wordUpper.length === 0) return false;
  if (wordUpper === masterWord.toUpperCase()) return false;
  if (correctWords.includes(wordUpper)) return false;

  return validateWordFromPool(masterWord, wordUpper);
};

  const handleSubmit = () => {
    if (!word.trim()) return;

    setTotalSubmissions((prev) => prev + 1);

    if (validateWord(word)) {
      setCorrectWords((prev) => [...prev, word.toUpperCase()]);
     const points = word.length * 10;

setPlayerScores((prev) => {
  const currentPlayer =
    prev.find((player) => player.name === username) || {
      name: username,
      score: 0,
      correctWords: 0,
      wrongWords: 0,
    };

  const updatedPlayer = {
    ...currentPlayer,
    score: currentPlayer.score + points,
    correctWords: currentPlayer.correctWords + 1,
  };

  const updatedScores = prev.some((player) => player.name === username)
    ? prev.map((player) =>
        player.name === username ? updatedPlayer : player
      )
    : [...prev, updatedPlayer];

  if (socket && isConnected && roomCode) {
    socket.emit("score-updated", {
      roomCode,
      username,
      score: updatedPlayer.score,
      correctWords: updatedPlayer.correctWords,
      wrongWords: updatedPlayer.wrongWords,
    });
  }

  return updatedScores;
});
      setFaceState("happy");
      setTimeout(() => setFaceState("neutral"), 1000);
    } else {
      setWrongGuesses((prev) => prev + 1);
      setPlayerScores((prev) => {
  const currentPlayer =
    prev.find((player) => player.name === username) || {
      name: username,
      score: 0,
      correctWords: 0,
      wrongWords: 0,
    };

  const updatedPlayer = {
    ...currentPlayer,
    wrongWords: currentPlayer.wrongWords + 1,
  };

  const updatedScores = prev.some((player) => player.name === username)
    ? prev.map((player) =>
        player.name === username ? updatedPlayer : player
      )
    : [...prev, updatedPlayer];

  if (socket && isConnected && roomCode) {
    socket.emit("score-updated", {
      roomCode,
      username,
      score: updatedPlayer.score,
      correctWords: updatedPlayer.correctWords,
      wrongWords: updatedPlayer.wrongWords,
    });
  }

  return updatedScores;
});
      setFaceState("sad");
      setTimeout(() => setFaceState("neutral"), 1000);
    }

    setWord("");
  };

  const getFaceIcon = () => {
    if (faceState === "happy") {
      return <SmilePlus className="w-12 h-12 text-green-500" />;
    } else if (faceState === "sad") {
      return <Frown className="w-12 h-12 text-red-500" />;
    } else {
      return (
        <div className="w-12 h-12 rounded-full bg-gray-400 flex items-center justify-center">
          <div className="text-white text-2xl">😐</div>
        </div>
      );
    }
  };

  const handleLeaveGame = () => {
    if (window.confirm("Are you sure you want to leave the game? Your progress will be lost.")) {
      navigate("/game");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Top Bar */}
        <div className="flex justify-between items-start mb-8">
          {/* Timer - Top Left */}
          <div className="bg-white rounded-lg shadow-lg p-4">
            <p className="text-lg font-semibold text-gray-700">
              {timeLeft} seconds left
            </p>
          </div>

          {/* Leave Game - Top Center */}
          <div className="bg-white rounded-lg shadow-lg">
            <Button
              onClick={handleLeaveGame}
              variant="outline"
              size="sm"
              className="bg-white hover:bg-red-50 border-red-300 text-red-600 hover:text-red-700"
            >
              Leave Game
            </Button>
          </div>

          {/* Face Indicator - Top Right */}
          <div className="bg-white rounded-lg shadow-lg p-4">
            {getFaceIcon()}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Game Area */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-2xl p-12">
              {/* Round Info */}
              <div className="flex justify-between items-center mb-6">
                <div className="text-lg font-semibold text-gray-700">
                  Round {currentRound + 1} / {TOTAL_ROUNDS}
                </div>
                <div className="text-2xl font-bold text-purple-600">
                  Your Score: {playerScores.find(p => p.name === username)?.score || 0}
                </div>
              </div>

              {/* Master Word */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-center text-gray-600 mb-4">
                  Master Word
                </h2>
                <p className="text-5xl font-bold text-center text-purple-600">
                  {masterWord}
                </p>
              </div>

              {/* Input Field */}
              <div className="mb-6">
                <label className="block text-lg font-semibold text-gray-700 mb-2">
                  Enter a word:
                </label>
                <input
                  type="text"
                  value={word}
                  onChange={(e) => setWord(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                  className="w-full p-4 border-2 border-gray-300 rounded-md text-xl"
                  placeholder="Type your word here..."
                />
              </div>

              {/* Submit Button */}
              <Button
                onClick={handleSubmit}
                className="w-full py-6 text-lg"
                size="lg"
              >
                Submit
              </Button>
            </div>

            {/* Correctly Guessed Words */}
            <div className="bg-white rounded-lg shadow-2xl p-6">
              <h3 className="text-xl font-bold text-center mb-4 text-gray-800">
                Your Correct Words
              </h3>
              {correctWords.length === 0 ? (
                <p className="text-center text-gray-500 text-sm">No words yet</p>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {correctWords.map((word, index) => (
                    <div
                      key={index}
                      className="bg-gray-50 rounded-md p-2 text-center text-sm font-medium text-green-600 border border-green-200"
                    >
                      {word}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Scoreboard */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-2xl p-6 sticky top-8">
              <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">
                Scoreboard
              </h2>

              <div className="space-y-3">
                {[...playerScores]
                  .sort((a, b) => b.score - a.score)
                  .map((player, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-md ${
                        player.name === username
                          ? "bg-purple-100 border-2 border-purple-400"
                          : "bg-gray-50"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-gray-400">
                            #{index + 1}
                          </span>
                          <span className="text-lg font-semibold text-gray-700">
                            {player.name}
                            {player.name === username && (
                              <span className="text-sm text-gray-500 ml-2">(You)</span>
                            )}
                          </span>
                        </div>
                        <span className="text-2xl font-bold text-purple-600">
                          {player.score}
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
