import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Users, Crown, RefreshCcw } from "lucide-react";
import { lobbyAPI } from "../../services/api";

interface PublicLobby {
  _id: string;
  roomCode: string;
  partyLeaderName: string;
  players: any[];
  maxPlayers: number;
  createdAt: string;
}

export function PublicLobbies() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [publicLobbies, setPublicLobbies] = useState<PublicLobby[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");

    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
      loadPublicLobbies();
    }
  }, [navigate]);

  const loadPublicLobbies = async () => {
    setLoading(true);
    setError("");

    try {
      const lobbies = await lobbyAPI.getPublicLobbies();
      setPublicLobbies(lobbies);
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to load lobbies");
    } finally {
      setLoading(false);
    }
  };

  const handleJoinLobby = async (roomCode: string) => {
    try {
      await lobbyAPI.joinLobby(roomCode);

      localStorage.setItem("roomCode", roomCode);
      localStorage.setItem("isPartyLeader", "false");

      navigate("/room-lobby");
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to join lobby");
    }
  };

  const handleBack = () => {
    navigate("/multiplayer");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-3xl">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Public Lobbies
        </h1>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        <div className="flex justify-between items-center mb-6">
          <p className="text-gray-600">
            {loading ? "Loading..." : `${publicLobbies.length} ${publicLobbies.length === 1 ? "lobby" : "lobbies"} available`}
          </p>
          <Button
            onClick={loadPublicLobbies}
            disabled={loading}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <RefreshCcw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        {!loading && publicLobbies.length === 0 ? (
          <div className="bg-gray-50 rounded-lg p-12 text-center mb-6">
            <p className="text-xl text-gray-500 mb-2">No public lobbies available</p>
            <p className="text-gray-400">Create one to get started!</p>
          </div>
        ) : (
          <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
            {publicLobbies.map((lobby, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors border-2 border-gray-200"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Crown className="w-5 h-5 text-yellow-600" />
                      <span className="text-lg font-semibold text-gray-800">
                        {lobby.partyLeaderName}'s Lobby
                      </span>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>
                          {lobby.players.length}/{lobby.maxPlayers} players
                        </span>
                      </div>
                      <div className="bg-purple-100 px-3 py-1 rounded-md">
                        <span className="text-purple-700 font-bold tracking-wider">
                          {lobby.roomCode}
                        </span>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={() => handleJoinLobby(lobby.roomCode)}
                    className="ml-4"
                  >
                    Join
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        <Button
          onClick={handleBack}
          className="w-full py-6 text-lg"
          size="lg"
          variant="outline"
        >
          Back
        </Button>
      </div>
    </div>
  );
}
