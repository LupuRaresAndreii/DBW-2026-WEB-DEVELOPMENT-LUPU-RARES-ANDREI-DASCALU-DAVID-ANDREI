import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { lobbyAPI } from "../../services/api";

export function MultiplayerMenu() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");
    
    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
    }
  }, [navigate]);

  const handleCreateRoom = async (isPublic: boolean) => {
    setLoading(true);
    setError("");

    try {
            const lobby = await lobbyAPI.createLobby({ isPublic });
      localStorage.setItem("roomCode", lobby.roomCode);
      localStorage.setItem("isPartyLeader", "true");

      navigate("/room-lobby");
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to create lobby");
    } finally {
      setLoading(false);
    }
  };

  const handleJoinRoom = () => {
    navigate("/join-room");
  };

  const handleBrowsePublicLobbies = () => {
    navigate("/public-lobbies");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Multiplayer Mode
        </h1>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        <div className="flex flex-col gap-4">
          <div className="space-y-2">
            <p className="text-center text-gray-600 text-sm mb-2">Create a room:</p>
            <Button
              onClick={() => handleCreateRoom(false)}
              disabled={loading}
              className="w-full py-6 text-lg"
              size="lg"
            >
              {loading ? "Creating..." : "Create Private Room"}
            </Button>

            <Button
              onClick={() => handleCreateRoom(true)}
              disabled={loading}
              className="w-full py-6 text-lg"
              size="lg"
              variant="secondary"
            >
              {loading ? "Creating..." : "Create Public Room"}
            </Button>
          </div>

          <div className="border-t border-gray-300 my-2"></div>

          <Button
            onClick={handleBrowsePublicLobbies}
            className="w-full py-6 text-lg"
            size="lg"
            variant="secondary"
          >
            Browse Public Lobbies
          </Button>

          <Button
            onClick={handleJoinRoom}
            className="w-full py-6 text-lg"
            size="lg"
            variant="secondary"
          >
            Join Private Room
          </Button>

          <Button
            onClick={() => navigate("/game")}
            className="w-full py-6 text-lg mt-4"
            size="lg"
            variant="outline"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  );
}