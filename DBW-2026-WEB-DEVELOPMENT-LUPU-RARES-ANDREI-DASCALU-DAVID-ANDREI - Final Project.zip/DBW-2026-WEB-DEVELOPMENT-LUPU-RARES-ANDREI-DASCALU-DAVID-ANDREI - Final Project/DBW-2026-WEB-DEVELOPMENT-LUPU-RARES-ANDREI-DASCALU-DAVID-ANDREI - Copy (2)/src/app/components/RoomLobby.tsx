import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Users, Crown } from "lucide-react";
import { useSocket } from "../../context/SocketContext";
import { lobbyAPI } from "../../services/api";
import { getRandomWords } from "../../utils/wordData";

interface Player {
  userId: string;
  username: string;
}

export function RoomLobby() {
  const navigate = useNavigate();
  const { socket, isConnected } = useSocket();
  const [username, setUsername] = useState("");
  const [userId, setUserId] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [isPartyLeader, setIsPartyLeader] = useState(false);
  const [partyLeaderName, setPartyLeaderName] = useState("");
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");
    const storedUserId = localStorage.getItem("userId");
    const storedRoomCode = localStorage.getItem("roomCode");
    const storedIsPartyLeader = localStorage.getItem("isPartyLeader");

    if (!isLoggedIn) {
      navigate("/");
      return;
    }

    setUsername(storedUsername || "User");
    setUserId(storedUserId || "");
    setRoomCode(storedRoomCode || "");
    setIsPartyLeader(storedIsPartyLeader === "true");

    // Load lobby data
    loadLobby(storedRoomCode || "", storedUserId || "");  }, [navigate]);

  // Socket.io connection
  useEffect(() => {
    if (!socket || !isConnected || !roomCode || !userId) return;

    // Join lobby room
    socket.emit("join-lobby", {
      roomCode,
      userId,
      username,
    });

    // Listen for lobby updates
    socket.on("lobby-updated", (lobby) => {
      setPlayers(lobby.players);
      setPartyLeaderName(lobby.partyLeaderName);

      const leaderId = getLeaderId(lobby.partyLeader);
      const amILeader = leaderId === userId;

      setIsPartyLeader(amILeader);
      localStorage.setItem("isPartyLeader", amILeader ? "true" : "false");
    });

    // Listen for game start
    socket.on("game-started", () => {
      navigate("/multiplayer-game");
    });

    // Listen for lobby closed
    socket.on("lobby-closed", () => {
      alert("Lobby was closed");
      navigate("/multiplayer");
    });

    return () => {
      socket.off("lobby-updated");
      socket.off("game-started");
      socket.off("lobby-closed");
    };
  }, [socket, isConnected, roomCode, userId, username, navigate]);

    const getLeaderId = (partyLeader: any) => {
    if (!partyLeader) return "";
    if (typeof partyLeader === "string") return partyLeader;
    if (partyLeader._id) return partyLeader._id.toString();
    return partyLeader.toString();
  };

   const loadLobby = async (code: string, currentUserId: string) => {
    try {
      const lobby = await lobbyAPI.getLobby(code);

      const leaderId = getLeaderId(lobby.partyLeader);
      const amILeader = leaderId === currentUserId;

      setPlayers(lobby.players);
      setPartyLeaderName(lobby.partyLeaderName);
      setIsPartyLeader(amILeader);

      localStorage.setItem("isPartyLeader", amILeader ? "true" : "false");
    } catch (err: any) {
      setError(err.message || "Failed to load lobby");
    } finally {
      setLoading(false);
    }
  };

  const handleLeaveRoom = async () => {
    try {
      if (socket && isConnected) {
        socket.emit("leave-lobby", { roomCode, userId });
      }

      await lobbyAPI.leaveLobby(roomCode);

      localStorage.removeItem("roomCode");
      localStorage.removeItem("isPartyLeader");

      navigate("/multiplayer");
    } catch (err: any) {
      console.error("Error leaving room:", err);
      navigate("/multiplayer");
    }
  };

  const handleStartGame = () => {
  if (!isPartyLeader) {
    alert("Only the party leader can start the game!");
    return;
  }

  const words = getRandomWords(5).map((item) => item.masterWord);

  localStorage.setItem("multiplayerWords", JSON.stringify(words));

  if (socket && isConnected) {
    socket.emit("start-game", {
      roomCode,
      words,
    });
  }
};

    

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
        <div className="bg-white rounded-lg shadow-2xl p-12">
          <p className="text-xl text-gray-700">Loading lobby...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-2xl">
        <h1 className="text-4xl font-bold text-center mb-2 text-gray-800">
          Room Lobby
        </h1>

        {!isConnected && (
          <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4">
            Connecting to server...
          </div>
        )}

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        {/* Room Code */}
        <div className="bg-gray-100 rounded-lg p-6 mb-6 text-center">
          <p className="text-gray-600 mb-2">Room Code</p>
          <p className="text-4xl font-bold text-purple-600 tracking-wider">
            {roomCode}
          </p>
        </div>

        {/* Party Leader */}
        <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-center gap-2">
            <Crown className="w-6 h-6 text-yellow-600" />
            <p className="text-lg font-semibold text-gray-800">
              Party Leader: {partyLeaderName}
            </p>
          </div>
        </div>

        {/* Players in Room */}
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-6 h-6 text-gray-600" />
            <h2 className="text-2xl font-bold text-gray-800">
              Players ({players.length})
            </h2>
          </div>

          <div className="space-y-2">
            {players.map((player, index) => (
              <div
                key={player.userId}
                className="flex items-center gap-3 p-3 bg-white rounded-md"
              >
                {player.username === partyLeaderName && <Crown className="w-5 h-5 text-yellow-600" />}
                <span className="text-lg font-semibold text-gray-700">
                  {player.username}
                </span>
                {player.username === username && (
                  <span className="ml-auto text-sm text-gray-500">(You)</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-4">
          {isPartyLeader && (
            <Button
              onClick={handleStartGame}
              className="w-full py-6 text-lg"
              size="lg"
            >
              Start Game
            </Button>
          )}
          
          <Button
            onClick={handleLeaveRoom}
            className="w-full py-6 text-lg"
            size="lg"
            variant="outline"
          >
            Leave Room
          </Button>
        </div>

        {!isPartyLeader && (
          <p className="text-center text-gray-500 mt-4">
            Waiting for party leader to start the game...
          </p>
        )}
      </div>
    </div>
  );
}