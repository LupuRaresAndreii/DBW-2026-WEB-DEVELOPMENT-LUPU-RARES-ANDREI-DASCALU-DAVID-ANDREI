import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router";
import { Button } from "./ui/button";
import { Trophy } from "lucide-react";

interface PlayerScore {
  name: string;
  score: number;
  correctWords?: number;
  wrongWords?: number;
}

export function MultiplayerGameOver() {
  const navigate = useNavigate();
  const location = useLocation();

  const [username, setUsername] = useState("");
  const [playerScores, setPlayerScores] = useState<PlayerScore[]>([]);
  const [currentPlayerStats, setCurrentPlayerStats] = useState({
    score: 0,
    correctWords: 0,
    wrongWords: 0,
  });

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username") || "User";

    if (!isLoggedIn) {
      navigate("/");
      return;
    }

    setUsername(storedUsername);

    const scoresFromGame = location.state?.playerScores || [];
    const myScore = location.state?.myScore ?? 0;
    const myCorrectWords = location.state?.correctWords ?? 0;
    const myWrongWords = location.state?.wrongWords ?? 0;

    setPlayerScores(scoresFromGame);

    setCurrentPlayerStats({
      score: myScore,
      correctWords: myCorrectWords,
      wrongWords: myWrongWords,
    });
  }, [navigate, location.state]);

  const handlePlayAgain = () => {
    navigate("/multiplayer-game");
  };

  const handleBackToMenu = () => {
    navigate("/game");
  };

  const sortedPlayers = [...playerScores].sort((a, b) => b.score - a.score);
  const currentPlayerRank =
    sortedPlayers.findIndex((p) => p.name === username) + 1 || 1;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-4xl">
        <h1 className="text-5xl font-bold text-center mb-2 text-gray-800">
          Game Complete
        </h1>

        <p className="text-center text-xl text-gray-600 mb-8">
          You finished in #{currentPlayerRank} place
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-gray-50 rounded-lg p-6">
            <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">
              Your Stats
            </h2>

            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-white rounded-md">
                <span className="text-lg font-semibold text-gray-700">
                  Final Score:
                </span>
                <span className="text-2xl font-bold text-purple-600">
                  {currentPlayerStats.score}
                </span>
              </div>

              <div className="flex justify-between items-center p-4 bg-white rounded-md">
                <span className="text-lg font-semibold text-gray-700">
                  Correct Words:
                </span>
                <span className="text-2xl font-bold text-green-600">
                  {currentPlayerStats.correctWords}
                </span>
              </div>

              <div className="flex justify-between items-center p-4 bg-white rounded-md">
                <span className="text-lg font-semibold text-gray-700">
                  Wrong Words:
                </span>
                <span className="text-2xl font-bold text-red-600">
                  {currentPlayerStats.wrongWords}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-6">
            <div className="flex items-center justify-center gap-2 mb-6">
              <Trophy className="w-6 h-6 text-yellow-600" />
              <h2 className="text-2xl font-bold text-gray-800">
                Final Scoreboard
              </h2>
            </div>

            {sortedPlayers.length === 0 ? (
              <p className="text-center text-gray-500">No scores available</p>
            ) : (
              <div className="space-y-3">
                {sortedPlayers.map((player, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-md ${
                      player.name === username
                        ? "bg-purple-100 border-2 border-purple-400"
                        : "bg-white"
                    } ${index === 0 ? "border-2 border-yellow-400" : ""}`}
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        {index === 0 && (
                          <Trophy className="w-5 h-5 text-yellow-600" />
                        )}
                        <span className="text-xl font-bold text-gray-400">
                          #{index + 1}
                        </span>
                        <span className="text-lg font-semibold text-gray-700">
                          {player.name}
                          {player.name === username && (
                            <span className="text-sm text-gray-500 ml-2">
                              (You)
                            </span>
                          )}
                        </span>
                      </div>

                      <span className="text-2xl font-bold text-purple-600">
                        {player.score}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={handlePlayAgain} className="flex-1 py-6 text-lg" size="lg">
            Play Again
          </Button>

          <Button
            onClick={handleBackToMenu}
            className="flex-1 py-6 text-lg"
            size="lg"
            variant="outline"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  );
}