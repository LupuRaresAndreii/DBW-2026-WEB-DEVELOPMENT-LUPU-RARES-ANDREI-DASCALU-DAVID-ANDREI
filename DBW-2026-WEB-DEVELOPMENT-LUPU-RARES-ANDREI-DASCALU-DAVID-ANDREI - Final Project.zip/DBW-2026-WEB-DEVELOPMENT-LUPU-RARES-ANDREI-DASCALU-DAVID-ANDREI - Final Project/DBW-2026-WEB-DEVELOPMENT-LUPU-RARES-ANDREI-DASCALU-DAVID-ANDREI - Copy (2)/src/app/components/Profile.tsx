import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Camera, User } from "lucide-react";
import { gameAPI, authAPI } from "../../services/api";

interface GameHistory {
  completedAt: string;
  finalScore: number;
  accuracy: number;
  totalCorrectWords: number;
  totalWrongWords: number;
}

interface WordStats {
  word: string;
  highScore: number;
  mostCorrectWords: number;
  mostWrongWords: number;
  timesPlayed: number;
}

export function Profile() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [selectedWord, setSelectedWord] = useState("");
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [gameHistory, setGameHistory] = useState<GameHistory[]>([]);
  const [wordStats, setWordStats] = useState<WordStats[]>([]);
  const [totalTimePlayed, setTotalTimePlayed] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");

    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
      loadProfile();
      loadGameHistory();
      loadUserStats();
    }
  }, [navigate]);

  const loadProfile = async () => {
    try {
      const profile = await authAPI.getProfile();
      setProfileImage(profile.profileImage);
    } catch (error) {
      console.error("Failed to load profile:", error);
    }
  };

  const loadGameHistory = async () => {
    try {
      const history = await gameAPI.getGameHistory();
      setGameHistory(history);
    } catch (error) {
      console.error("Failed to load game history:", error);
    }
  };

  const loadUserStats = async () => {
    try {
      const stats = await gameAPI.getUserStats();
      setWordStats(stats.wordStats || []);
      setTotalTimePlayed(stats.totalTimePlayed || 0);

      if (stats.wordStats && stats.wordStats.length > 0) {
        setSelectedWord(stats.wordStats[0].word);
      }
    } catch (error) {
      console.error("Failed to load stats:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const imageData = reader.result as string;
        setProfileImage(imageData);

        try {
          await authAPI.updateProfile({ profileImage: imageData });
        } catch (error) {
          console.error("Failed to update profile image:", error);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const currentStats = wordStats.find(ws => ws.word === selectedWord) || {
    highScore: 0,
    mostCorrectWords: 0,
    mostWrongWords: 0,
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}min`;
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-2xl">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Profile
        </h1>

        {/* Profile Picture */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative">
            <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-4 border-gray-300">
              {profileImage ? (
                <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-16 h-16 text-gray-400" />
              )}
            </div>
          </div>
          
          {/* Change Picture Button */}
          <label className="mt-4 cursor-pointer">
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors">
              <Camera className="w-4 h-4 text-gray-600" />
              <span className="text-gray-700">Change Picture</span>
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
          </label>
        </div>

        {/* Username */}
        <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
          {username}
        </h2>

        {/* Word Selector for Stats */}
        {wordStats.length > 0 && (
          <div className="mb-6">
            <label className="block text-lg font-semibold text-gray-700 mb-2">
              Select Word for Statistics:
            </label>
            <select
              value={selectedWord}
              onChange={(e) => setSelectedWord(e.target.value)}
              className="w-full p-3 border-2 border-gray-300 rounded-md text-lg bg-white"
            >
              {wordStats.map((ws) => (
                <option key={ws.word} value={ws.word}>
                  {ws.word}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Statistics */}
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">
            Statistics
          </h3>

          <div className="space-y-4">
            {/* Per-word stats */}
            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">High Score:</span>
              <span className="text-2xl font-bold text-blue-600">{currentStats.highScore}</span>
            </div>

            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">Most Correct Words Guessed:</span>
              <span className="text-2xl font-bold text-green-600">{currentStats.mostCorrectWords}</span>
            </div>

            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">Most Wrong Words:</span>
              <span className="text-2xl font-bold text-red-600">{currentStats.mostWrongWords}</span>
            </div>

            <hr className="border-gray-300 my-2" />

            {/* General stat */}
            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">Total Time Played:</span>
              <span className="text-2xl font-bold text-purple-600">{formatTime(totalTimePlayed)}</span>
            </div>
          </div>
        </div>

        {/* Game History */}
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">
            Recent Games
          </h3>

          {loading ? (
            <p className="text-center text-gray-500">Loading...</p>
          ) : gameHistory.length === 0 ? (
            <p className="text-center text-gray-500">No games played yet</p>
          ) : (
            <div className="space-y-3">
              {gameHistory.map((game, index) => (
                <div
                  key={index}
                  className="p-4 bg-white rounded-md border border-gray-200"
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-500">
                      {new Date(game.completedAt).toLocaleDateString()} {new Date(game.completedAt).toLocaleTimeString()}
                    </span>
                    <span className="text-lg font-bold text-purple-600">
                      Score: {game.finalScore}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div className="text-center">
                      <p className="text-gray-500">Accuracy</p>
                      <p className="font-bold text-blue-600">{game.accuracy.toFixed(1)}%</p>
                    </div>
                    <div className="text-center">
                      <p className="text-gray-500">Correct</p>
                      <p className="font-bold text-green-600">{game.totalCorrectWords}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-gray-500">Wrong</p>
                      <p className="font-bold text-red-600">{game.totalWrongWords}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <Button
          onClick={() => navigate("/game")}
          className="w-full py-6 text-lg"
          size="lg"
        >
          Back to Menu
        </Button>
      </div>
    </div>
  );
}
