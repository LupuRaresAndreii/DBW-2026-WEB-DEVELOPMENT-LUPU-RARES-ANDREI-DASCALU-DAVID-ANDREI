import Lobby from '../models/Lobby.js';

export const createLobby = async (req, res) => {
  try {
    const { isPublic } = req.body;
    const roomCode = generateRoomCode();

    const lobby = await Lobby.create({
      roomCode,
      partyLeader: req.user._id,
      partyLeaderName: req.user.username,
      players: [{
        userId: req.user._id,
        username: req.user.username
      }],
      isPublic: isPublic || false
    });

    res.status(201).json(lobby);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getPublicLobbies = async (req, res) => {
  try {
    const lobbies = await Lobby.find({
      isPublic: true,
      status: 'waiting',
      $expr: { $lt: [{ $size: '$players' }, '$maxPlayers'] }
    }).sort({ createdAt: -1 });

    res.json(lobbies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const joinLobby = async (req, res) => {
  try {
    const { roomCode } = req.body;

    const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

    if (!lobby) {
      return res.status(404).json({ message: 'Lobby not found' });
    }

    if (lobby.players.length >= lobby.maxPlayers) {
      return res.status(400).json({ message: 'Lobby is full' });
    }

    if (lobby.status !== 'waiting') {
      return res.status(400).json({ message: 'Game already started' });
    }

    const alreadyInLobby = lobby.players.some(p => p.userId.toString() === req.user._id.toString());

    if (!alreadyInLobby) {
      lobby.players.push({
        userId: req.user._id,
        username: req.user.username
      });
      await lobby.save();
    }

    res.json(lobby);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getLobby = async (req, res) => {
  try {
    const { roomCode } = req.params;
    const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

    if (!lobby) {
      return res.status(404).json({ message: 'Lobby not found' });
    }

    res.json(lobby);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const leaveLobby = async (req, res) => {
  try {
    const { roomCode } = req.body;
    const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

    if (!lobby) {
      return res.status(404).json({ message: 'Lobby not found' });
    }

    lobby.players = lobby.players.filter(p => p.userId.toString() !== req.user._id.toString());

    if (lobby.players.length === 0) {
      await Lobby.deleteOne({ _id: lobby._id });
      return res.json({ message: 'Lobby deleted' });
    }

    // If party leader left, assign new leader
    if (lobby.partyLeader.toString() === req.user._id.toString() && lobby.players.length > 0) {
      lobby.partyLeader = lobby.players[0].userId;
      lobby.partyLeaderName = lobby.players[0].username;
    }

    await lobby.save();
    res.json(lobby);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

function generateRoomCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}