import Game from '../models/Game.js';
import User from '../models/User.js';

export const saveGame = async (req, res) => {
  try {
    const {
      gameMode,
      rounds,
      finalScore,
      totalCorrectWords,
      totalWrongWords,
      accuracy,
      wordsUsed
    } = req.body;

    const game = await Game.create({
      userId: req.user._id,
      gameMode,
      rounds,
      finalScore,
      totalCorrectWords,
      totalWrongWords,
      accuracy,
      wordsUsed
    });

    // Update user stats
    const user = await User.findById(req.user._id);

    // Update word stats
    wordsUsed.forEach(word => {
      const wordStat = user.stats.wordStats.find(ws => ws.word === word);
      const roundData = rounds.find(r => r.masterWord === word);

      if (wordStat && roundData) {
        wordStat.highScore = Math.max(wordStat.highScore, roundData.score);
        wordStat.mostCorrectWords = Math.max(wordStat.mostCorrectWords, roundData.correctWords.length);
        wordStat.mostWrongWords = Math.max(wordStat.mostWrongWords, roundData.wrongWords.length);
        wordStat.timesPlayed += 1;
      } else if (roundData) {
        user.stats.wordStats.push({
          word,
          highScore: roundData.score,
          mostCorrectWords: roundData.correctWords.length,
          mostWrongWords: roundData.wrongWords.length,
          timesPlayed: 1
        });
      }
    });

    // Update total time played (approximate based on rounds)
    const totalTime = rounds.reduce((acc, round) => acc + (round.duration || 60), 0);
    user.stats.totalTimePlayed += totalTime;

    await user.save();

    res.status(201).json(game);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getGameHistory = async (req, res) => {
  try {
    const games = await Game.find({ userId: req.user._id })
      .sort({ completedAt: -1 })
      .limit(5);

    res.json(games);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getUserStats = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('stats');
    res.json(user.stats);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};