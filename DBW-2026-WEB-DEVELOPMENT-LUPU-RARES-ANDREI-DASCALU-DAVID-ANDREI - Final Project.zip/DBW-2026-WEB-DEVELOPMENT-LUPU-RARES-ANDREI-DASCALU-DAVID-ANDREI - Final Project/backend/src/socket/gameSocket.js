const roomScores = {};
const roomWords = {};

export function setupGameSocket(io) {
  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join-lobby", ({ roomCode, userId, username }) => {
      socket.join(roomCode);
      console.log(`${username} joined lobby ${roomCode}`);
    });

    socket.on("leave-lobby", ({ roomCode }) => {
      socket.leave(roomCode);
      console.log(`User left lobby ${roomCode}`);
    });

    socket.on("start-game", ({ roomCode, words }) => {
      console.log("Starting game for room:", roomCode);

      roomWords[roomCode] = words;

      if (!roomScores[roomCode]) {
        roomScores[roomCode] = {};
      }

      io.to(roomCode).emit("game-started", {
        words: roomWords[roomCode],
      });
    });

    socket.on("join-game", ({ roomCode, username }) => {
      socket.join(roomCode);
      console.log(`${username} joined game ${roomCode}`);

      if (!roomScores[roomCode]) {
        roomScores[roomCode] = {};
      }

      if (!roomScores[roomCode][username]) {
        roomScores[roomCode][username] = {
          name: username,
          score: 0,
          correctWords: 0,
          wrongWords: 0,
        };
      }

      socket.emit("game-words", {
        words: roomWords[roomCode] || [],
      });

      io.to(roomCode).emit(
        "scoreboard-updated",
        Object.values(roomScores[roomCode])
      );
    });

    socket.on(
      "score-updated",
      ({ roomCode, username, score, correctWords, wrongWords }) => {
        if (!roomScores[roomCode]) {
          roomScores[roomCode] = {};
        }

        roomScores[roomCode][username] = {
          name: username,
          score,
          correctWords,
          wrongWords,
        };

        io.to(roomCode).emit(
          "scoreboard-updated",
          Object.values(roomScores[roomCode])
        );
      }
    );

    socket.on("game-finished", ({ roomCode }) => {
      const finalScores = Object.values(roomScores[roomCode] || {});
      io.to(roomCode).emit("final-scoreboard", finalScores);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });
}