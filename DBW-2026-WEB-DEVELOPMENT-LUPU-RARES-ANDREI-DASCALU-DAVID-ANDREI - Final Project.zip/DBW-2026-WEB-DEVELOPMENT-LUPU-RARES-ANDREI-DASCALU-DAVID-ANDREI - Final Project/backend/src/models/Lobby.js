import mongoose from 'mongoose';

const lobbySchema = new mongoose.Schema({
  roomCode: {
    type: String,
    required: true,
    unique: true,
    uppercase: true
  },
  partyLeader: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  partyLeaderName: {
    type: String,
    required: true
  },
  players: [{
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    username: String,
    socketId: String
  }],
  isPublic: {
    type: Boolean,
    default: false
  },
  maxPlayers: {
    type: Number,
    default: 4
  },
  status: {
    type: String,
    enum: ['waiting', 'playing', 'finished'],
    default: 'waiting'
  },
  gameState: {
    currentRound: { type: Number, default: 0 },
    masterWords: [String],
    playerScores: [{
      userId: mongoose.Schema.Types.ObjectId,
      username: String,
      score: { type: Number, default: 0 },
      correctWords: [String],
      wrongGuesses: { type: Number, default: 0 }
    }],
    roundStartTime: Date,
    roundDuration: { type: Number, default: 60 }
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 3600 // Auto-delete after 1 hour
  }
});

const Lobby = mongoose.model('Lobby', lobbySchema);

export default Lobby;