import mongoose from 'mongoose';

const wordSchema = new mongoose.Schema({
  masterWord: {
    type: String,
    required: true,
    unique: true,
    uppercase: true
  },
  subWords: [{
    type: String,
    uppercase: true
  }],
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    default: 'medium'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Word = mongoose.model('Word', wordSchema);

export default Word;