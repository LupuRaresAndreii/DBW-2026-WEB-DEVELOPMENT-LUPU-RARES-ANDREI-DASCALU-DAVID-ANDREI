import mongoose from 'mongoose';

const gameSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  gameMode: {
    type: String,
    enum: ['singleplayer', 'multiplayer'],
    required: true
  },
  rounds: [{
    masterWord: String,
    correctWords: [String],
    wrongWords: [String],
    score: Number,
    duration: Number
  }],
  finalScore: {
    type: Number,
    required: true
  },
  totalCorrectWords: {
    type: Number,
    required: true
  },
  totalWrongWords: {
    type: Number,
    required: true
  },
  accuracy: {
    type: Number,
    required: true
  },
  wordsUsed: [{
    type: String
  }],
  completedAt: {
    type: Date,
    default: Date.now
  }
});

const Game = mongoose.model('Game', gameSchema);

export default Game;