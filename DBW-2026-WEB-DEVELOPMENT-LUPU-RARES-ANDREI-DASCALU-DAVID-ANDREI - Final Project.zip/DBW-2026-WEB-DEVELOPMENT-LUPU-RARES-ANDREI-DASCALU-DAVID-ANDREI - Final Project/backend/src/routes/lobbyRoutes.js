import express from 'express';
import {
  createLobby,
  getPublicLobbies,
  joinLobby,
  getLobby,
  leaveLobby
} from '../controllers/lobbyController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

router.post('/create', protect, createLobby);
router.get('/public', protect, getPublicLobbies);
router.post('/join', protect, joinLobby);
router.get('/:roomCode', protect, getLobby);
router.post('/leave', protect, leaveLobby);

export default router;