import express from 'express';
import { saveGame, getGameHistory, getUserStats } from '../controllers/gameController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

router.post('/save', protect, saveGame);
router.get('/history', protect, getGameHistory);
router.get('/stats', protect, getUserStats);

export default router;