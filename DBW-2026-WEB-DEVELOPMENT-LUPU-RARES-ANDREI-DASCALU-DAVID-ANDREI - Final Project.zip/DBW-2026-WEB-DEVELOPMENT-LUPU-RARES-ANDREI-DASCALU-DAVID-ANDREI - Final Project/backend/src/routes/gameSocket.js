import Lobby from '../models/Lobby.js';
import { validateWord, getRandomWords } from '../utils/wordData.js';

export const setupGameSocket = (io) => {
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // Join lobby room
    socket.on('join-lobby', async (data) => {
      const { roomCode, userId, username } = data;

      try {
        const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

        if (lobby) {
          socket.join(roomCode);

          // Update socket ID
          const player = lobby.players.find(p => p.userId.toString() === userId);
          if (player) {
            player.socketId = socket.id;
            await lobby.save();
          }

          io.to(roomCode).emit('lobby-updated', lobby);
        }
      } catch (error) {
        console.error('Join lobby error:', error);
      }
    });

    // Start game
    socket.on('start-game', async (data) => {
      const { roomCode } = data;

      try {
        const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

        if (lobby) {
          lobby.status = 'playing';
          lobby.gameState.currentRound = 0;
          lobby.gameState.masterWords = getRandomWords(5).map(w => w.masterWord);
          lobby.gameState.playerScores = lobby.players.map(p => ({
            userId: p.userId,
            username: p.username,
            score: 0,
            correctWords: [],
            wrongGuesses: 0
          }));
          lobby.gameState.roundStartTime = new Date();

          await lobby.save();

          io.to(roomCode).emit('game-started', {
            masterWord: lobby.gameState.masterWords[0],
            round: 1,
            totalRounds: 5
          });
        }
      } catch (error) {
        console.error('Start game error:', error);
      }
    });

    // Submit word
    socket.on('submit-word', async (data) => {
      const { roomCode, userId, word } = data;

      try {
        const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

        if (lobby && lobby.status === 'playing') {
          const currentMasterWord = lobby.gameState.masterWords[lobby.gameState.currentRound];
          const playerScore = lobby.gameState.playerScores.find(p => p.userId.toString() === userId);

          if (playerScore) {
            const isValid = validateWord(currentMasterWord, word);
            const wordUpper = word.toUpperCase();
            const alreadyGuessed = playerScore.correctWords.includes(wordUpper);

            if (isValid && !alreadyGuessed) {
              playerScore.correctWords.push(wordUpper);
              playerScore.score += word.length * 10;

              await lobby.save();

              io.to(roomCode).emit('word-accepted', {
                userId,
                word: wordUpper,
                points: word.length * 10,
                playerScores: lobby.gameState.playerScores
              });
            } else {
              playerScore.wrongGuesses += 1;
              await lobby.save();

              socket.emit('word-rejected', {
                word: wordUpper,
                reason: alreadyGuessed ? 'Already guessed' : 'Invalid word'
              });
            }
          }
        }
      } catch (error) {
        console.error('Submit word error:', error);
      }
    });

    // Round timer ended
    socket.on('round-ended', async (data) => {
      const { roomCode } = data;

      try {
        const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

        if (lobby) {
          lobby.gameState.currentRound += 1;

          if (lobby.gameState.currentRound >= 5) {
            lobby.status = 'finished';
            await lobby.save();

            io.to(roomCode).emit('game-finished', {
              playerScores: lobby.gameState.playerScores
            });
          } else {
            lobby.gameState.roundStartTime = new Date();
            await lobby.save();

            io.to(roomCode).emit('next-round', {
              masterWord: lobby.gameState.masterWords[lobby.gameState.currentRound],
              round: lobby.gameState.currentRound + 1,
              totalRounds: 5
            });
          }
        }
      } catch (error) {
        console.error('Round ended error:', error);
      }
    });

    // Leave lobby
    socket.on('leave-lobby', async (data) => {
      const { roomCode, userId } = data;

      try {
        const lobby = await Lobby.findOne({ roomCode: roomCode.toUpperCase() });

        if (lobby) {
          lobby.players = lobby.players.filter(p => p.userId.toString() !== userId);

          if (lobby.players.length === 0) {
            await Lobby.deleteOne({ _id: lobby._id });
            io.to(roomCode).emit('lobby-closed');
          } else {
            // If party leader left, assign new leader
            if (lobby.partyLeader.toString() === userId && lobby.players.length > 0) {
              lobby.partyLeader = lobby.players[0].userId;
              lobby.partyLeaderName = lobby.players[0].username;
            }

            await lobby.save();
            io.to(roomCode).emit('lobby-updated', lobby);
          }

          socket.leave(roomCode);
        }
      } catch (error) {
        console.error('Leave lobby error:', error);
      }
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });
};