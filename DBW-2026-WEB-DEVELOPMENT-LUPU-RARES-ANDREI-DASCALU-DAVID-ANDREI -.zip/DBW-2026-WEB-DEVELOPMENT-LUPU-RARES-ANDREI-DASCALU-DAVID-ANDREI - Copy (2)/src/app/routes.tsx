import { createBrowserRouter } from "react-router";
import { MainMenu } from "./components/MainMenu";
import { LoginPage } from "./components/LoginPage";
import { SignUpPage } from "./components/SignUpPage";
import { GameMenu } from "./components/GameMenu";
import { SingleplayerGame } from "./components/SingleplayerGame";
import { GameOver } from "./components/GameOver";
import { GameRules } from "./components/GameRules";
import { Profile } from "./components/Profile";
import { MultiplayerMenu } from "./components/MultiplayerMenu";
import { JoinRoom } from "./components/JoinRoom";
import { RoomLobby } from "./components/RoomLobby";
import { MultiplayerGame } from "./components/MultiplayerGame";
import { MultiplayerGameOver } from "./components/MultiplayerGameOver";
import { PublicLobbies } from "./components/PublicLobbies";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: MainMenu,
  },
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/signup",
    Component: SignUpPage,
  },
  {
    path: "/game",
    Component: GameMenu,
  },
  {
    path: "/singleplayer",
    Component: SingleplayerGame,
  },
  {
    path: "/game-over",
    Component: GameOver,
  },
  {
    path: "/game-rules",
    Component: GameRules,
  },
  {
    path: "/profile",
    Component: Profile,
  },
  {
    path: "/multiplayer",
    Component: MultiplayerMenu,
  },
  {
    path: "/join-room",
    Component: JoinRoom,
  },
  {
    path: "/public-lobbies",
    Component: PublicLobbies,
  },
  {
    path: "/room-lobby",
    Component: RoomLobby,
  },
  {
    path: "/multiplayer-game",
    Component: MultiplayerGame,
  },
  {
    path: "/multiplayer-game-over",
    Component: MultiplayerGameOver,
  },
]);