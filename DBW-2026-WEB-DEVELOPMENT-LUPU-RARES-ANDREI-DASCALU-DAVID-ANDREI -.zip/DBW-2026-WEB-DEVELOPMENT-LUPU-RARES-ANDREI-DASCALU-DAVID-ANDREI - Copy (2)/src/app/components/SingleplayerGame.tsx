import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Smile, Frown, Meh } from "lucide-react";

const MASTER_WORDS = ["MASTERWORD", "WONDERFUL", "BEAUTIFUL", "EXTRAORDINARY", "INCREDIBLE"];
const ROUND_DURATION = 60;
const TOTAL_ROUNDS = 5;

export function SingleplayerGame() {
  const navigate = useNavigate();
  const [subWord, setSubWord] = useState("");
  const [faceState, setFaceState] = useState<"neutral" | "happy" | "sad">("neutral");
  const [currentRound, setCurrentRound] = useState(0);
  const [masterWord, setMasterWord] = useState(MASTER_WORDS[0]);
  const [timeLeft, setTimeLeft] = useState(ROUND_DURATION);
  const [score, setScore] = useState(0);
  const [correctWords, setCorrectWords] = useState<string[]>([]);
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [totalSubmissions, setTotalSubmissions] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Round ended
          if (currentRound + 1 >= TOTAL_ROUNDS) {
            // Game over
            const accuracy = totalSubmissions > 0 ? (correctWords.length / totalSubmissions) * 100 : 0;
            navigate("/game-over", {
              state: {
                finalScore: score,
                correctWords: correctWords.length,
                wrongWords: wrongGuesses,
                accuracy: accuracy.toFixed(1),
                correctWordsList: correctWords,
              },
            });
            return 0;
          } else {
            // Next round
            setCurrentRound((prev) => prev + 1);
            setMasterWord(MASTER_WORDS[(currentRound + 1) % MASTER_WORDS.length]);
            return ROUND_DURATION;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentRound, navigate, score, correctWords, wrongGuesses, totalSubmissions]);

  const validateWord = (word: string): boolean => {
    const wordUpper = word.toUpperCase();
    const masterUpper = masterWord.toUpperCase();

    if (wordUpper.length === 0 || wordUpper === masterUpper) return false;
    if (correctWords.includes(wordUpper)) return false;

    const masterLetters = masterUpper.split('');
    const wordLetters = wordUpper.split('');

    for (const letter of wordLetters) {
      const indexInMaster = masterLetters.indexOf(letter);
      if (indexInMaster === -1) return false;
      masterLetters.splice(indexInMaster, 1);
    }

    return true;
  };

  const handleSubmit = () => {
    if (!subWord.trim()) return;

    setTotalSubmissions((prev) => prev + 1);

    if (validateWord(subWord)) {
      setCorrectWords((prev) => [...prev, subWord.toUpperCase()]);
      setScore((prev) => prev + subWord.length * 10);
      setFaceState("happy");
      setTimeout(() => setFaceState("neutral"), 1000);
    } else {
      setWrongGuesses((prev) => prev + 1);
      setFaceState("sad");
      setTimeout(() => setFaceState("neutral"), 1000);
    }

    setSubWord("");
  };

  const renderFace = () => {
    if (faceState === "happy") {
      return <Smile className="w-16 h-16 text-green-500" />;
    } else if (faceState === "sad") {
      return <Frown className="w-16 h-16 text-red-500" />;
    }
    return <Meh className="w-16 h-16 text-gray-400" />;
  };

  const handleLeaveGame = () => {
    if (window.confirm("Are you sure you want to leave the game? Your progress will be lost.")) {
      navigate("/game");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-4xl relative">
        {/* Timer - top left */}
        <div className="absolute top-8 left-8">
          <p className="text-xl font-semibold text-gray-700">{timeLeft} seconds left</p>
        </div>

        {/* Face indicator - top right */}
        <div className="absolute top-8 right-8">
          {renderFace()}
        </div>

        {/* Leave Game button - top center */}
        <div className="absolute top-8 left-1/2 transform -translate-x-1/2">
          <Button
            onClick={handleLeaveGame}
            variant="outline"
            size="sm"
            className="bg-white hover:bg-red-50 border-red-300 text-red-600 hover:text-red-700"
          >
            Leave Game
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Game Area */}
          <div className="lg:col-span-2">
            {/* Round and Score Info */}
            <div className="flex justify-between items-center mb-6 mt-8">
              <div className="text-lg font-semibold text-gray-700">
                Round {currentRound + 1} / {TOTAL_ROUNDS}
              </div>
              <div className="text-2xl font-bold text-purple-600">
                Score: {score}
              </div>
            </div>

            {/* Master Word - slightly above center */}
            <div className="text-center mb-8">
              <h2 className="text-2xl mb-2 text-gray-700">Master Word:</h2>
              <p className="text-5xl font-bold text-gray-800">{masterWord}</p>
            </div>

            {/* Enter Sub Word - center */}
            <div className="text-center mb-8">
              <h3 className="text-xl mb-4 text-gray-700">Enter Sub Word:</h3>
              <div className="border-2 border-gray-300 rounded-md p-3 max-w-md mx-auto bg-yellow-100">
                <Input
                  type="text"
                  value={subWord}
                  onChange={(e) => setSubWord(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                  className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 bg-transparent text-center text-lg"
                  placeholder="Type your word here..."
                />
              </div>

              <Button
                onClick={handleSubmit}
                className="mt-6 px-12 py-6 text-lg"
                size="lg"
              >
                Submit
              </Button>
            </div>
          </div>

          {/* Correctly Guessed Words List */}
          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-lg p-4 max-h-96 overflow-y-auto">
              <h3 className="text-xl font-bold text-center mb-4 text-gray-800">
                Correct Words
              </h3>
              {correctWords.length === 0 ? (
                <p className="text-center text-gray-500 text-sm">No words yet</p>
              ) : (
                <div className="space-y-2">
                  {correctWords.map((word, index) => (
                    <div
                      key={index}
                      className="bg-white rounded-md p-2 text-center text-sm font-medium text-green-600 border border-green-200"
                    >
                      {word}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
