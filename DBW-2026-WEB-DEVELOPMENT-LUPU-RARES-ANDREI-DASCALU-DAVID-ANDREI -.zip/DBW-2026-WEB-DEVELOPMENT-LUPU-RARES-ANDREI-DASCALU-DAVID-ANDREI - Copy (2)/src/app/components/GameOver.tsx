import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router";
import { Button } from "./ui/button";

export function GameOver() {
  const navigate = useNavigate();
  const location = useLocation();
  const { finalScore = 0, correctWords = 0, wrongWords = 0, accuracy = "0", correctWordsList = [] } = location.state || {};

  useEffect(() => {
    const existingHistory = JSON.parse(localStorage.getItem("gameHistory") || "[]");
    const newGame = {
      date: new Date().toISOString(),
      score: finalScore,
      accuracy: parseFloat(accuracy),
      correctWords,
      wrongWords,
      totalSubmissions: correctWords + wrongWords,
    };

    const updatedHistory = [newGame, ...existingHistory].slice(0, 5);
    localStorage.setItem("gameHistory", JSON.stringify(updatedHistory));
  }, [finalScore, correctWords, wrongWords, accuracy]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        {/* Message slightly above center */}
        <h1 className="text-4xl font-bold text-center mb-12 text-gray-800">
          Game Complete
        </h1>

        {/* Stats in center */}
        <div className="text-center mb-8 space-y-4">
          <p className="text-2xl text-gray-700">
            <span className="font-semibold">Final Score:</span> {finalScore}
          </p>
          <p className="text-2xl text-gray-700">
            <span className="font-semibold">Correct Words:</span> {correctWords}
          </p>
          <p className="text-2xl text-gray-700">
            <span className="font-semibold">Wrong Words:</span> {wrongWords}
          </p>
          <p className="text-2xl text-gray-700">
            <span className="font-semibold">Accuracy:</span> {accuracy}%
          </p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col gap-4 mt-12">
          <Button
            onClick={() => navigate("/singleplayer")}
            className="w-full py-6 text-lg"
            size="lg"
          >
            Play Again
          </Button>
          <Button
            onClick={() => navigate("/game")}
            className="w-full py-6 text-lg"
            size="lg"
            variant="outline"
          >
            Back To Main Menu
          </Button>
        </div>
      </div>
    </div>
  );
}
