import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { SmilePlus, Frown } from "lucide-react";

const MASTER_WORDS = ["MASTERWORD", "WONDERFUL", "BEAUTIFUL", "EXTRAORDINARY", "INCREDIBLE"];
const ROUND_DURATION = 60;
const TOTAL_ROUNDS = 5;

interface PlayerScore {
  name: string;
  score: number;
}

export function MultiplayerGame() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [word, setWord] = useState("");
  const [faceState, setFaceState] = useState<"neutral" | "happy" | "sad">("neutral");
  const [timeLeft, setTimeLeft] = useState(ROUND_DURATION);
  const [currentRound, setCurrentRound] = useState(0);
  const [masterWord, setMasterWord] = useState(MASTER_WORDS[0]);
  const [correctWords, setCorrectWords] = useState<string[]>([]);
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [totalSubmissions, setTotalSubmissions] = useState(0);

  // Mock player scores - in real implementation this would be synced with backend
  const [playerScores, setPlayerScores] = useState<PlayerScore[]>([
    { name: "Player1", score: 0 },
    { name: "Player2", score: 0 },
    { name: "Player3", score: 0 },
  ]);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");

    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
      // Update player scores with actual username
      setPlayerScores(prev =>
        prev.map((player, index) =>
          index === 0 ? { ...player, name: storedUsername || "User" } : player
        )
      );
    }
  }, [navigate]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Round ended
          if (currentRound + 1 >= TOTAL_ROUNDS) {
            // Game over
            const myScore = playerScores.find(p => p.name === username)?.score || 0;
            const accuracy = totalSubmissions > 0 ? (correctWords.length / totalSubmissions) * 100 : 0;
            navigate("/multiplayer-game-over", {
              state: {
                playerScores,
                myScore,
                correctWords: correctWords.length,
                wrongWords: wrongGuesses,
                accuracy: accuracy.toFixed(1),
              },
            });
            return 0;
          } else {
            // Next round
            setCurrentRound((prev) => prev + 1);
            setMasterWord(MASTER_WORDS[(currentRound + 1) % MASTER_WORDS.length]);
            return ROUND_DURATION;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentRound, navigate, playerScores, username, correctWords, wrongGuesses, totalSubmissions]);

  const validateWord = (word: string): boolean => {
    const wordUpper = word.toUpperCase();
    const masterUpper = masterWord.toUpperCase();

    if (wordUpper.length === 0 || wordUpper === masterUpper) return false;
    if (correctWords.includes(wordUpper)) return false;

    const masterLetters = masterUpper.split('');
    const wordLetters = wordUpper.split('');

    for (const letter of wordLetters) {
      const indexInMaster = masterLetters.indexOf(letter);
      if (indexInMaster === -1) return false;
      masterLetters.splice(indexInMaster, 1);
    }

    return true;
  };

  const handleSubmit = () => {
    if (!word.trim()) return;

    setTotalSubmissions((prev) => prev + 1);

    if (validateWord(word)) {
      setCorrectWords((prev) => [...prev, word.toUpperCase()]);
      const points = word.length * 10;
      setPlayerScores((prev) =>
        prev.map((player) =>
          player.name === username ? { ...player, score: player.score + points } : player
        )
      );
      setFaceState("happy");
      setTimeout(() => setFaceState("neutral"), 1000);
    } else {
      setWrongGuesses((prev) => prev + 1);
      setFaceState("sad");
      setTimeout(() => setFaceState("neutral"), 1000);
    }

    setWord("");
  };

  const getFaceIcon = () => {
    if (faceState === "happy") {
      return <SmilePlus className="w-12 h-12 text-green-500" />;
    } else if (faceState === "sad") {
      return <Frown className="w-12 h-12 text-red-500" />;
    } else {
      return (
        <div className="w-12 h-12 rounded-full bg-gray-400 flex items-center justify-center">
          <div className="text-white text-2xl">😐</div>
        </div>
      );
    }
  };

  const handleLeaveGame = () => {
    if (window.confirm("Are you sure you want to leave the game? Your progress will be lost.")) {
      navigate("/game");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Top Bar */}
        <div className="flex justify-between items-start mb-8">
          {/* Timer - Top Left */}
          <div className="bg-white rounded-lg shadow-lg p-4">
            <p className="text-lg font-semibold text-gray-700">
              {timeLeft} seconds left
            </p>
          </div>

          {/* Leave Game - Top Center */}
          <div className="bg-white rounded-lg shadow-lg">
            <Button
              onClick={handleLeaveGame}
              variant="outline"
              size="sm"
              className="bg-white hover:bg-red-50 border-red-300 text-red-600 hover:text-red-700"
            >
              Leave Game
            </Button>
          </div>

          {/* Face Indicator - Top Right */}
          <div className="bg-white rounded-lg shadow-lg p-4">
            {getFaceIcon()}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Game Area */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-2xl p-12">
              {/* Round Info */}
              <div className="flex justify-between items-center mb-6">
                <div className="text-lg font-semibold text-gray-700">
                  Round {currentRound + 1} / {TOTAL_ROUNDS}
                </div>
                <div className="text-2xl font-bold text-purple-600">
                  Your Score: {playerScores.find(p => p.name === username)?.score || 0}
                </div>
              </div>

              {/* Master Word */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-center text-gray-600 mb-4">
                  Master Word
                </h2>
                <p className="text-5xl font-bold text-center text-purple-600">
                  {masterWord}
                </p>
              </div>

              {/* Input Field */}
              <div className="mb-6">
                <label className="block text-lg font-semibold text-gray-700 mb-2">
                  Enter a word:
                </label>
                <input
                  type="text"
                  value={word}
                  onChange={(e) => setWord(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                  className="w-full p-4 border-2 border-gray-300 rounded-md text-xl"
                  placeholder="Type your word here..."
                />
              </div>

              {/* Submit Button */}
              <Button
                onClick={handleSubmit}
                className="w-full py-6 text-lg"
                size="lg"
              >
                Submit
              </Button>
            </div>

            {/* Correctly Guessed Words */}
            <div className="bg-white rounded-lg shadow-2xl p-6">
              <h3 className="text-xl font-bold text-center mb-4 text-gray-800">
                Your Correct Words
              </h3>
              {correctWords.length === 0 ? (
                <p className="text-center text-gray-500 text-sm">No words yet</p>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {correctWords.map((word, index) => (
                    <div
                      key={index}
                      className="bg-gray-50 rounded-md p-2 text-center text-sm font-medium text-green-600 border border-green-200"
                    >
                      {word}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Scoreboard */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-2xl p-6 sticky top-8">
              <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">
                Scoreboard
              </h2>

              <div className="space-y-3">
                {playerScores
                  .sort((a, b) => b.score - a.score)
                  .map((player, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-md ${
                        player.name === username
                          ? "bg-purple-100 border-2 border-purple-400"
                          : "bg-gray-50"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-gray-400">
                            #{index + 1}
                          </span>
                          <span className="text-lg font-semibold text-gray-700">
                            {player.name}
                            {player.name === username && (
                              <span className="text-sm text-gray-500 ml-2">(You)</span>
                            )}
                          </span>
                        </div>
                        <span className="text-2xl font-bold text-purple-600">
                          {player.score}
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
