import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Users, Crown, RefreshCcw } from "lucide-react";

interface PublicLobby {
  roomCode: string;
  partyLeader: string;
  playerCount: number;
  maxPlayers: number;
  createdAt: string;
}

export function PublicLobbies() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [publicLobbies, setPublicLobbies] = useState<PublicLobby[]>([]);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");

    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
      loadPublicLobbies();
    }
  }, [navigate]);

  const loadPublicLobbies = () => {
    const lobbies = JSON.parse(localStorage.getItem("publicLobbies") || "[]");
    // Filter out full lobbies and sort by most recent
    const availableLobbies = lobbies
      .filter((lobby: PublicLobby) => lobby.playerCount < lobby.maxPlayers)
      .sort((a: PublicLobby, b: PublicLobby) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    setPublicLobbies(availableLobbies);
  };

  const handleJoinLobby = (roomCode: string) => {
    localStorage.setItem("roomCode", roomCode);
    localStorage.setItem("isPartyLeader", "false");
    navigate("/room-lobby");
  };

  const handleBack = () => {
    navigate("/multiplayer");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-3xl">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Public Lobbies
        </h1>

        <div className="flex justify-between items-center mb-6">
          <p className="text-gray-600">
            {publicLobbies.length} {publicLobbies.length === 1 ? "lobby" : "lobbies"} available
          </p>
          <Button
            onClick={loadPublicLobbies}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <RefreshCcw className="w-4 h-4" />
            Refresh
          </Button>
        </div>

        {publicLobbies.length === 0 ? (
          <div className="bg-gray-50 rounded-lg p-12 text-center mb-6">
            <p className="text-xl text-gray-500 mb-2">No public lobbies available</p>
            <p className="text-gray-400">Create one to get started!</p>
          </div>
        ) : (
          <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
            {publicLobbies.map((lobby, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-lg p-6 hover:bg-gray-100 transition-colors border-2 border-gray-200"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Crown className="w-5 h-5 text-yellow-600" />
                      <span className="text-lg font-semibold text-gray-800">
                        {lobby.partyLeader}'s Lobby
                      </span>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>
                          {lobby.playerCount}/{lobby.maxPlayers} players
                        </span>
                      </div>
                      <div className="bg-purple-100 px-3 py-1 rounded-md">
                        <span className="text-purple-700 font-bold tracking-wider">
                          {lobby.roomCode}
                        </span>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={() => handleJoinLobby(lobby.roomCode)}
                    className="ml-4"
                  >
                    Join
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        <Button
          onClick={handleBack}
          className="w-full py-6 text-lg"
          size="lg"
          variant="outline"
        >
          Back
        </Button>
      </div>
    </div>
  );
}
