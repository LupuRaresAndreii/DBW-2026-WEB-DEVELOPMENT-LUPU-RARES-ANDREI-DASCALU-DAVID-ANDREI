import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";

export function MultiplayerMenu() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");
    
    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
    }
  }, [navigate]);

  const handleCreateRoom = (isPublic: boolean) => {
    // Generate a random room code
    const roomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    localStorage.setItem("roomCode", roomCode);
    localStorage.setItem("isPartyLeader", "true");
    localStorage.setItem("isPublicRoom", isPublic.toString());

    // If public, add to public lobbies list
    if (isPublic) {
      const publicLobbies = JSON.parse(localStorage.getItem("publicLobbies") || "[]");
      publicLobbies.push({
        roomCode,
        partyLeader: username,
        playerCount: 1,
        maxPlayers: 4,
        createdAt: new Date().toISOString(),
      });
      localStorage.setItem("publicLobbies", JSON.stringify(publicLobbies));
    }

    navigate("/room-lobby");
  };

  const handleJoinRoom = () => {
    navigate("/join-room");
  };

  const handleBrowsePublicLobbies = () => {
    navigate("/public-lobbies");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Multiplayer Mode
        </h1>

        <div className="flex flex-col gap-4">
          <div className="space-y-2">
            <p className="text-center text-gray-600 text-sm mb-2">Create a room:</p>
            <Button
              onClick={() => handleCreateRoom(false)}
              className="w-full py-6 text-lg"
              size="lg"
            >
              Create Private Room
            </Button>

            <Button
              onClick={() => handleCreateRoom(true)}
              className="w-full py-6 text-lg"
              size="lg"
              variant="secondary"
            >
              Create Public Room
            </Button>
          </div>

          <div className="border-t border-gray-300 my-2"></div>

          <Button
            onClick={handleBrowsePublicLobbies}
            className="w-full py-6 text-lg"
            size="lg"
            variant="secondary"
          >
            Browse Public Lobbies
          </Button>

          <Button
            onClick={handleJoinRoom}
            className="w-full py-6 text-lg"
            size="lg"
            variant="secondary"
          >
            Join Private Room
          </Button>

          <Button
            onClick={() => navigate("/game")}
            className="w-full py-6 text-lg mt-4"
            size="lg"
            variant="outline"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  );
}