import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";

export function GameMenu() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");
    
    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("username");
    navigate("/");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        <h1 className="text-4xl font-bold text-center mb-2 text-gray-800">
          Matryoshka Doll of Words
        </h1>
        <p className="text-center text-gray-600 mb-8">Welcome, {username}!</p>
        
        <div className="flex flex-col gap-4">
          <Button
            onClick={() => navigate("/singleplayer")}
            className="w-full py-6 text-lg"
            size="lg"
          >
            Singleplayer Mode
          </Button>
          
          <Button
            onClick={() => navigate("/multiplayer")}
            className="w-full py-6 text-lg"
            size="lg"
            variant="secondary"
          >
            Multiplayer Mode
          </Button>
          
          <Button
            onClick={() => navigate("/profile")}
            className="w-full py-6 text-lg"
            size="lg"
            variant="secondary"
          >
            Profile
          </Button>
          
          <Button
            onClick={() => navigate("/game-rules")}
            className="w-full py-6 text-lg"
            size="lg"
            variant="secondary"
          >
            Game Rules
          </Button>
          
          <Button
            onClick={handleLogout}
            className="w-full py-6 text-lg mt-4"
            size="lg"
            variant="outline"
          >
            Log Out
          </Button>
        </div>
      </div>
    </div>
  );
}