import { useNavigate } from "react-router";
import { Button } from "./ui/button";

export function GameRules() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-3xl">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Game Rules
        </h1>

        <div className="space-y-6">
          <p className="text-xl text-gray-700">
            You will receive a <span className="font-semibold">Master Word</span> 🔠
          </p>

          <p className="text-xl text-gray-700">
            Your goal is to discover as many <span className="font-semibold">valid words</span> as possible hidden inside it 🏠✨
          </p>

          <hr className="border-gray-300 my-8" />

          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">📋 Rules</h2>
            <ul className="space-y-3 ml-6">
              <li className="text-xl text-gray-700">
                🔠 Letters must follow the <span className="font-semibold">same order</span> as in the master word
              </li>
              <li className="text-xl text-gray-700">
                ➖ Letters <span className="font-semibold">don't need to be consecutive</span>
              </li>
              <li className="text-xl text-gray-700">
                ✅ Each <span className="font-semibold">valid word</span> earns you <span className="font-semibold">points</span>
              </li>
              <li className="text-xl text-gray-700">
                📝 <span className="font-semibold">Longer words</span> give you more points
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8">
          <Button
            onClick={() => navigate("/game")}
            className="w-full py-6 text-lg"
            size="lg"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  );
}
