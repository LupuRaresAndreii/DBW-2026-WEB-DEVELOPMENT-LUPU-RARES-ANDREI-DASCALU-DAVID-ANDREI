import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Users, Crown } from "lucide-react";

export function RoomLobby() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [isPartyLeader, setIsPartyLeader] = useState(false);
  
  // Mock players - in real implementation this would come from a backend
  const [players, setPlayers] = useState<string[]>([]);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");
    const storedRoomCode = localStorage.getItem("roomCode");
    const storedIsPartyLeader = localStorage.getItem("isPartyLeader");
    
    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
      setRoomCode(storedRoomCode || "");
      setIsPartyLeader(storedIsPartyLeader === "true");
      
      // Initialize players list
      if (storedIsPartyLeader === "true") {
        // If party leader, they are first in the list
        setPlayers([storedUsername || "User"]);
      } else {
        // If joining, add some mock players including the party leader
        setPlayers(["PartyLeader", storedUsername || "User", "Player3"]);
      }
    }
  }, [navigate]);

  const handleLeaveRoom = () => {
    localStorage.removeItem("roomCode");
    localStorage.removeItem("isPartyLeader");
    navigate("/multiplayer");
  };

  const handleStartGame = () => {
    if (!isPartyLeader) {
      alert("Only the party leader can start the game!");
      return;
    }
    navigate("/multiplayer-game");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-2xl">
        <h1 className="text-4xl font-bold text-center mb-2 text-gray-800">
          Room Lobby
        </h1>
        
        {/* Room Code */}
        <div className="bg-gray-100 rounded-lg p-6 mb-6 text-center">
          <p className="text-gray-600 mb-2">Room Code</p>
          <p className="text-4xl font-bold text-purple-600 tracking-wider">
            {roomCode}
          </p>
        </div>

        {/* Party Leader */}
        <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-center gap-2">
            <Crown className="w-6 h-6 text-yellow-600" />
            <p className="text-lg font-semibold text-gray-800">
              Party Leader: {players[0]}
            </p>
          </div>
        </div>

        {/* Players in Room */}
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-6 h-6 text-gray-600" />
            <h2 className="text-2xl font-bold text-gray-800">
              Players ({players.length})
            </h2>
          </div>
          
          <div className="space-y-2">
            {players.map((player, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-3 bg-white rounded-md"
              >
                {index === 0 && <Crown className="w-5 h-5 text-yellow-600" />}
                <span className="text-lg font-semibold text-gray-700">
                  {player}
                </span>
                {player === username && (
                  <span className="ml-auto text-sm text-gray-500">(You)</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-4">
          {isPartyLeader && (
            <Button
              onClick={handleStartGame}
              className="w-full py-6 text-lg"
              size="lg"
            >
              Start Game
            </Button>
          )}
          
          <Button
            onClick={handleLeaveRoom}
            className="w-full py-6 text-lg"
            size="lg"
            variant="outline"
          >
            Leave Room
          </Button>
        </div>

        {!isPartyLeader && (
          <p className="text-center text-gray-500 mt-4">
            Waiting for party leader to start the game...
          </p>
        )}
      </div>
    </div>
  );
}