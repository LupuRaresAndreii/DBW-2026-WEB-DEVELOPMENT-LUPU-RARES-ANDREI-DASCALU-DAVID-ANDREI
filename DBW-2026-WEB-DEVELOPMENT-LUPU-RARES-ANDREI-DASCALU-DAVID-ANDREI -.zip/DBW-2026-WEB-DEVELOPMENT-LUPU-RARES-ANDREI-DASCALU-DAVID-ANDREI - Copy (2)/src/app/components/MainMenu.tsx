import { useNavigate } from "react-router";
import { Button } from "./ui/button";

export function MainMenu() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Matryoshka Doll of Words
        </h1>
        <div className="flex flex-col gap-4">
          <Button
            onClick={() => navigate("/login")}
            className="w-full py-6 text-lg"
            size="lg"
          >
            Log In
          </Button>
          <Button
            onClick={() => navigate("/signup")}
            className="w-full py-6 text-lg"
            size="lg"
            variant="outline"
          >
            Sign Up
          </Button>
        </div>
      </div>
    </div>
  );
}
