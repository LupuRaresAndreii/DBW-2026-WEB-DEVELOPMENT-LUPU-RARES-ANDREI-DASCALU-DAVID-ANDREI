import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Camera, User } from "lucide-react";

interface GameHistory {
  date: string;
  score: number;
  accuracy: number;
  correctWords: number;
  wrongWords: number;
  totalSubmissions: number;
}

export function Profile() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [selectedWord, setSelectedWord] = useState("masterword1");
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [gameHistory, setGameHistory] = useState<GameHistory[]>([]);

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");

    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
      // Load game history
      const history = JSON.parse(localStorage.getItem("gameHistory") || "[]");
      setGameHistory(history);
    }
  }, [navigate]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Mock data - will be replaced with actual stats later
  const wordStats = {
    masterword1: {
      highScore: 150,
      mostCorrectWords: 12,
      mostWrongWords: 3,
    },
    masterword2: {
      highScore: 200,
      mostCorrectWords: 15,
      mostWrongWords: 2,
    },
    masterword3: {
      highScore: 180,
      mostCorrectWords: 14,
      mostWrongWords: 4,
    },
  };

  const currentStats = wordStats[selectedWord as keyof typeof wordStats];
  const totalTimePlayed = "2h 34min"; // General stat

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-8">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-2xl">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Profile
        </h1>

        {/* Profile Picture */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative">
            <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-4 border-gray-300">
              {profileImage ? (
                <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-16 h-16 text-gray-400" />
              )}
            </div>
          </div>
          
          {/* Change Picture Button */}
          <label className="mt-4 cursor-pointer">
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors">
              <Camera className="w-4 h-4 text-gray-600" />
              <span className="text-gray-700">Change Picture</span>
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
          </label>
        </div>

        {/* Username */}
        <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
          {username}
        </h2>

        {/* Word Selector for Stats */}
        <div className="mb-6">
          <label className="block text-lg font-semibold text-gray-700 mb-2">
            Select Word for Statistics:
          </label>
          <select
            value={selectedWord}
            onChange={(e) => setSelectedWord(e.target.value)}
            className="w-full p-3 border-2 border-gray-300 rounded-md text-lg bg-white"
          >
            <option value="masterword1">Master Word 1</option>
            <option value="masterword2">Master Word 2</option>
            <option value="masterword3">Master Word 3</option>
          </select>
        </div>

        {/* Statistics */}
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">
            Statistics
          </h3>

          <div className="space-y-4">
            {/* Per-word stats */}
            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">High Score:</span>
              <span className="text-2xl font-bold text-blue-600">{currentStats.highScore}</span>
            </div>

            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">Most Correct Words Guessed:</span>
              <span className="text-2xl font-bold text-green-600">{currentStats.mostCorrectWords}</span>
            </div>

            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">Most Wrong Words:</span>
              <span className="text-2xl font-bold text-red-600">{currentStats.mostWrongWords}</span>
            </div>

            <hr className="border-gray-300 my-2" />

            {/* General stat */}
            <div className="flex justify-between items-center p-4 bg-white rounded-md">
              <span className="text-lg font-semibold text-gray-700">Total Time Played:</span>
              <span className="text-2xl font-bold text-purple-600">{totalTimePlayed}</span>
            </div>
          </div>
        </div>

        {/* Game History */}
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">
            Recent Games
          </h3>

          {gameHistory.length === 0 ? (
            <p className="text-center text-gray-500">No games played yet</p>
          ) : (
            <div className="space-y-3">
              {gameHistory.map((game, index) => (
                <div
                  key={index}
                  className="p-4 bg-white rounded-md border border-gray-200"
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-500">
                      {new Date(game.date).toLocaleDateString()} {new Date(game.date).toLocaleTimeString()}
                    </span>
                    <span className="text-lg font-bold text-purple-600">
                      Score: {game.score}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div className="text-center">
                      <p className="text-gray-500">Accuracy</p>
                      <p className="font-bold text-blue-600">{game.accuracy.toFixed(1)}%</p>
                    </div>
                    <div className="text-center">
                      <p className="text-gray-500">Correct</p>
                      <p className="font-bold text-green-600">{game.correctWords}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-gray-500">Wrong</p>
                      <p className="font-bold text-red-600">{game.wrongWords}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <Button
          onClick={() => navigate("/game")}
          className="w-full py-6 text-lg"
          size="lg"
        >
          Back to Menu
        </Button>
      </div>
    </div>
  );
}
