import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export function LoginPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    // Simulate login - in prototype, just check if fields are filled
    if (username && password) {
      localStorage.setItem("isLoggedIn", "true");
      localStorage.setItem("username", username);
      navigate("/game");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
          Log In
        </h1>
        
        <div className="flex flex-col gap-4 mb-6">
          <div className="border-2 border-gray-300 rounded-md p-3">
            <Input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>
          
          <div className="border-2 border-gray-300 rounded-md p-3">
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>
          
          <Button
            onClick={handleLogin}
            className="w-full py-6 text-lg mt-2"
            size="lg"
          >
            LOGIN
          </Button>
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-600 mb-4">Don't have an account?</p>
          <Button
            onClick={() => navigate("/signup")}
            variant="outline"
            className="w-full py-6 text-lg"
            size="lg"
          >
            Sign UP
          </Button>
        </div>
      </div>
    </div>
  );
}
