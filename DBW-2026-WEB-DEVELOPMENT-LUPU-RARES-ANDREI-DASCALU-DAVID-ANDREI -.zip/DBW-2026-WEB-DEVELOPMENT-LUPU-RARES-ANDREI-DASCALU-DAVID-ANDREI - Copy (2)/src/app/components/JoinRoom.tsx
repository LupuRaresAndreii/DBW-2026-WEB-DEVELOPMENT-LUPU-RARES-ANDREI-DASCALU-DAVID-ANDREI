import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";

export function JoinRoom() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [roomCode, setRoomCode] = useState("");

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const storedUsername = localStorage.getItem("username");
    
    if (!isLoggedIn) {
      navigate("/");
    } else {
      setUsername(storedUsername || "User");
    }
  }, [navigate]);

  const handleSubmit = () => {
    if (!roomCode.trim()) {
      alert("Please enter a room code!");
      return;
    }
    
    // Store room code and set as non-party leader
    localStorage.setItem("roomCode", roomCode.toUpperCase());
    localStorage.setItem("isPartyLeader", "false");
    navigate("/room-lobby");
  };

  const handleBack = () => {
    navigate("/multiplayer");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Join Room
        </h1>
        
        <div className="mb-6">
          <label className="block text-lg font-semibold text-gray-700 mb-2">
            Enter Room Code:
          </label>
          <input
            type="text"
            value={roomCode}
            onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
            className="w-full p-4 border-2 border-gray-300 rounded-md text-xl text-center tracking-wider font-bold"
            placeholder="ABC123"
            maxLength={6}
          />
        </div>
        
        <div className="flex flex-col gap-4">
          <Button
            onClick={handleSubmit}
            className="w-full py-6 text-lg"
            size="lg"
          >
            Submit
          </Button>
          
          <Button
            onClick={handleBack}
            className="w-full py-6 text-lg"
            size="lg"
            variant="outline"
          >
            Back
          </Button>
        </div>
      </div>
    </div>
  );
}
