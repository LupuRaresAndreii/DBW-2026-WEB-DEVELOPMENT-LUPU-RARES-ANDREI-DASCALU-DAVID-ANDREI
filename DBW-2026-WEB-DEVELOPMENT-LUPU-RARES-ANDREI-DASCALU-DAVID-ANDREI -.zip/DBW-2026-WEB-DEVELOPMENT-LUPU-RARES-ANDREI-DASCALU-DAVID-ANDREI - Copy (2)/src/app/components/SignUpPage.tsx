import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export function SignUpPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleRegister = () => {
    // Simulate registration - in prototype, just check if fields are filled and passwords match
    if (username && password && password === confirmPassword) {
      localStorage.setItem("isLoggedIn", "true");
      localStorage.setItem("username", username);
      navigate("/game");
    } else if (password !== confirmPassword) {
      alert("Passwords do not match!");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-500 via-pink-500 to-red-500">
      <div className="bg-white rounded-lg shadow-2xl p-12 w-full max-w-md">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
          Sign Up
        </h1>
        
        <div className="flex flex-col gap-4 mb-6">
          <div className="border-2 border-gray-300 rounded-md p-3">
            <Input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>
          
          <div className="border-2 border-gray-300 rounded-md p-3">
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>
          
          <div className="border-2 border-gray-300 rounded-md p-3">
            <Input
              type="password"
              placeholder="Confirm Password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
          </div>
          
          <Button
            onClick={handleRegister}
            className="w-full py-6 text-lg mt-2"
            size="lg"
          >
            REGISTER
          </Button>
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-600 mb-4">Already have an account?</p>
          <Button
            onClick={() => navigate("/login")}
            variant="outline"
            className="w-full py-6 text-lg"
            size="lg"
          >
            Login
          </Button>
        </div>
      </div>
    </div>
  );
}
